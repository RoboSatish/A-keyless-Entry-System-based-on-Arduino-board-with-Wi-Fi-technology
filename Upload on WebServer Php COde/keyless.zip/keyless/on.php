<html lang = "en">
   
   <head>
      <title>KeyLess</title>
      <link href = "css/bootstrap.min.css" rel = "stylesheet">
      <link href = "css/bootstrap.css" rel = "stylesheet">
      <script src="js/jquery-3.4.1.js"></script> 
      <style>
         body {
            padding-top: 40px;
            padding-bottom: 40px;
            background-image: url('images/bg1.jpg');
            background-size: cover;

         }
         
         .form-signin {
            max-width: 330px;
            padding: 15px;
            margin: 0 auto;
            color: #017572;
         }
         
         .form-signin .form-signin-heading,
         .form-signin .checkbox {
            margin-bottom: 10px;
         }
         
         .form-signin .checkbox {
            font-weight: normal;
         }
         
         .form-signin .form-control {
            position: relative;
            height: auto;
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
            padding: 10px;
            font-size: 16px;
         }
         
         .form-signin .form-control:focus {
            z-index: 2;
         }
         
         .form-signin input[type="email"] {
            margin-bottom: -1px;
            border-bottom-right-radius: 0;
            border-bottom-left-radius: 0;
            border-color:#017572;
         }
         
      
         
         h2{
            text-align: center;
            color: #017572;
         }
         .login_form{
            background: rgba(199, 192, 187, 0.5);
            padding: 40px 35px 10px 10px;
            margin-left: 15%;
            margin-right: 15%;
           }
      </style>
      
   </head>
	
   <body>
      
      <h2 style="color: #f5f6f7" align="center"><b>A keyless Entry System based on Arduino board with Wi-Fi technology</b></h2> 
      <div class = "container form-signin">
      <h1 "color: #f5f6f7" align="center">    Wait For few minute....................!</h1>
	  </div>

<iframe src="http://api.thingspeak.com/update?api_key=8NUC0I1CEIQ2POXU&field1=0&field2=0" width="5%" height="5"></iframe>
<meta charset="UTF-8">
    <meta http-equiv="refresh" content="15; url=valid.php">
</body>
</html>